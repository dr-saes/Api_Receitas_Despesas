package br.com.danielsaes.api_receitas_despesas.controller.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.domain.Page;

import br.com.danielsaes.api_receitas_despesas.modelo.Despesa;

public class DespesaDtoListagem {

	private String descricao;
	private LocalDate dataDespesa;
	private BigDecimal valorDespesa;

	public DespesaDtoListagem() {
	}

	public DespesaDtoListagem(Despesa despesa) {
		this.descricao = despesa.getDescricao();
		this.dataDespesa = despesa.getDataDespesa();
		this.valorDespesa = despesa.getValorDespesa();
	}
	
	public DespesaDtoListagem(Optional<Despesa> despesa) {
		this.descricao = despesa.get().getDescricao();
		this.dataDespesa = despesa.get().getDataDespesa();
		this.valorDespesa = despesa.get().getValorDespesa();
	}


	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public LocalDate getDataDespesa() {
		return dataDespesa;
	}

	public void setDataCriacao(LocalDate dataDespesa) {
		this.dataDespesa = dataDespesa;
	}

	public BigDecimal getValorReceita() {
		return valorDespesa;
	}

	public void setValorReceita(BigDecimal valorDespesa) {
		this.valorDespesa = valorDespesa;
	}

	public static Page<DespesaDtoListagem> converterLista(Page<Despesa> listaDespesas) {
		return listaDespesas.map(DespesaDtoListagem::new);
	}
	
}
