package br.com.danielsaes.api_receitas_despesas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.danielsaes.api_receitas_despesas.modelo.Receita;

@Repository
public interface ReceitaRepository extends JpaRepository<Receita, Long> {

	@Query("SELECT mesReceita, descricao FROM Receita  WHERE mesReceita = :mesReceita and descricao = :descricao")
	List<Receita> findByMesEDescricao(@Param("mesReceita") int mesReceita, @Param("descricao") String descricao);

}
