package br.com.danielsaes.api_receitas_despesas.controller;


import java.net.URI;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.danielsaes.api_receitas_despesas.controller.dto.DespesaDto;
import br.com.danielsaes.api_receitas_despesas.controller.form.AtualizacaoDespesaForm;
import br.com.danielsaes.api_receitas_despesas.controller.form.DespesaForm;
import br.com.danielsaes.api_receitas_despesas.modelo.Despesa;
import br.com.danielsaes.api_receitas_despesas.repository.DespesaRepository;

@RestController
@RequestMapping("/despesas")
public class DespesaController {

	@Autowired
	private DespesaRepository despesaRepository;

	@PostMapping
	@Transactional
	public ResponseEntity<DespesaDto> cadastrarDespesa(@RequestBody @Valid DespesaForm form,
			UriComponentsBuilder uriBuilder) throws Exception {

		Despesa despesa = new Despesa();
		despesa = form.toDespesa();

		try {
			if (!despesaRepository.findByMesEDescricao(despesa.getMesDespesa(), despesa.getDescricao()).isEmpty()) {
			}
		} catch (Exception e) {
			throw new IllegalArgumentException("Despesa com essa descrição já criada com esse mês!");
		}

		despesaRepository.save(despesa);
		URI uri = uriBuilder.path("/despesas/{id}").buildAndExpand(despesa.getId()).toUri();
		return ResponseEntity.created(uri).body(new DespesaDto(despesa));
	}

	@GetMapping
	public Page<DespesaDto> listarDespesas(
			@PageableDefault(sort = "id", direction = Direction.ASC, page = 0, size = 100) Pageable paginacao) {

		Page<Despesa> listaDespesas = despesaRepository.findAll(paginacao);

		//return DespesaDtoListagem.converter(listaDespesas);
		return DespesaDto.converterLista(listaDespesas);
	}

	@GetMapping("/{id}")
	public ResponseEntity<DespesaDto> listarPorId(@PathVariable Long id) {

		Optional<Despesa> despesa = despesaRepository.findById(id);
		if (despesa.isPresent() & despesa != null) {
			return ResponseEntity.ok(new DespesaDto(despesa));
		} else {
			throw new IllegalArgumentException("Id inexistente");
		}

//		Optional<Receita> receita = receitaRepository.findById(id);
//		if (receita.isPresent() & receita != null) {
//			return ResponseEntity.ok(new ReceitaDto(receita));
//		}
//		return ResponseEntity.notFound().build();
//		//return ResponseEntity.noContent().build();

	}

	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<DespesaDto> atualizar(@PathVariable Long id,
			@RequestBody @Valid AtualizacaoDespesaForm form) {
		Optional<Despesa> optional = despesaRepository.findById(id);
		if (optional.isPresent()) {
			Optional<Despesa> despesa = form.atualizar(id, despesaRepository);
			return ResponseEntity.ok(new DespesaDto(despesa));
		} else {
			throw new IllegalArgumentException("Id inexistente");
		}
	}
	
	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<DespesaDto> deletar (@PathVariable Long id){
		Optional<Despesa> despesa = despesaRepository.findById(id);
		if(despesa.isPresent()) {
			despesaRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}else {
			throw new IllegalArgumentException("Id inexistente");
		}
	}
}
