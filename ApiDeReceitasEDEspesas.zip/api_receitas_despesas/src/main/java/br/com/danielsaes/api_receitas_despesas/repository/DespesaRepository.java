package br.com.danielsaes.api_receitas_despesas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.danielsaes.api_receitas_despesas.modelo.Despesa;

@Repository
public interface DespesaRepository extends JpaRepository<Despesa, Long> {

	@Query("SELECT mesDespesa, descricao FROM Despesa  WHERE mesDespesa = :mesDespesa and descricao = :descricao")
	List<Despesa> findByMesEDescricao(@Param("mesDespesa") int mesReceita, @Param("descricao") String descricao);

}
