package br.com.danielsaes.api_receitas_despesas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiReceitasDespesasApplicationTests {

	@Test
	void contextLoads() {
	}

}
